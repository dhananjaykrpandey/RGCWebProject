# LiteDB.Studio

A GUI tool for viewing and editing documents for LiteDB v5

![LiteDB Studio](https://pbs.twimg.com/media/D_142rzWwAECJDd?format=jpg&name=900x900)
