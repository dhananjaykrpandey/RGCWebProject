﻿namespace whatsapp.dotnet
{
    public class QrCode
    {
        public string base64 { get; set; }

        public string code { get; set; }

        public string clientId { get; set; }
    }
}