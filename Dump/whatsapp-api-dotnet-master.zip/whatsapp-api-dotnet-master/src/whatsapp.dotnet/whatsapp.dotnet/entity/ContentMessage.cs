﻿namespace whatsapp.dotnet
{
    public class ContentMessage
    {
        public MessageMedia messageMedia { get; set; }
        public Location location { get; set; }
        public string msg { get; set; }
    }
}