﻿namespace whatsapp.dotnet
{
    public class ProfilePicThumbObj
    {
        public string eurl { get; set; }

        public string img { get; set; }

        public string imgFull { get; set; }
    }
}