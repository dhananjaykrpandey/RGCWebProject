﻿namespace whatsapp.dotnet
{
    public class MessageMedia
    {
        public string mimetype { get; set; }
        public string data { get; set; }
        public string filename { get; set; }
    }
}