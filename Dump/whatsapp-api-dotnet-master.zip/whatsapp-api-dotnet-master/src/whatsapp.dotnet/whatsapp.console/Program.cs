﻿using System;
using whatsapp.console.infra;

namespace whatsapp.console
{
    class Program
    {
        /// <summary>
        /// TO ASSIST IN THE GENERATION AND UPDATE OF JS
        /// REFERENCE AND CREDITS  https://github.com/pedroslopez/whatsapp-web.js/ 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
             //   JsFile.GenerateEncripty();  /* CONVERTS JAVASCRIPTS FROM THE "ARTIFACTS/LIB/JS" FOLDER TO "ARTIFACTS/LIB/ENC"  */ 
            //   dotnet.JsFile.Build(); /*GENERATES STRUCTURE FOR DLL*/
        }
    }
}
